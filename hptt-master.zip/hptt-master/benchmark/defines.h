#include <complex>

using FloatComplex = std::complex<float>;
using DoubleComplex = std::complex<double>;

typedef float floatType;
//typedef double floatType;
//typedef DoubleComplex floatType;
//typedef FloatComplex floatType;


